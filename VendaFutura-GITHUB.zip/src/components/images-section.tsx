import { motion } from "framer-motion";

export default function ImagesSection() {
  return (
    <section className="py-8 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex justify-center items-center gap-4 max-w-2xl mx-auto">
          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://i.ibb.co/1YczTmZt/Whats-App-Image-2025-07-28-at-17-39-41-1.jpg"
              alt="Moldes Pet - Imagem 1"
              className="w-full h-auto rounded-lg shadow-md max-w-xs"
            />
          </motion.div>
          
          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://i.ibb.co/Xf3Yvy3V/Whats-App-Image-2025-07-28-at-17-39-41.jpg"
              alt="Moldes Pet - Imagem 2"
              className="w-full h-auto rounded-lg shadow-md max-w-xs"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}